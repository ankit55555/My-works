import flask
from flask import request, jsonify

app = flask.Flask(__name__)
app.config["DEBUG"] = True

# fetch the data from mftool
from mftool import Mftool
mf = Mftool()
all_scheme_codes = mf.get_scheme_codes()

# endpoints for homepage
@app.route('/', methods=['GET'])
def home():
    return '''<h1>This is the homepage</h1>
<p>It will give a list of mutual funds scheme and scheme codes</p>'''


#endpoints for mutual funds scheme and scheme codes
@app.route('/api/mutual', methods=['GET'])
def api_all():
    return jsonify(all_scheme_codes)

app.run(port=5005)